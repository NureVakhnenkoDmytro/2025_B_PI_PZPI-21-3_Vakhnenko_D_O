﻿using Booking.DAL.EF;
using Microsoft.EntityFrameworkCore;

namespace Booking.DAL.Repositories.Common
{
    abstract class BaseRepository
    {
        protected readonly IDbContextFactory<BookingDbContext> _contextFactory;

        public BaseRepository(IDbContextFactory<BookingDbContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
    }
}
