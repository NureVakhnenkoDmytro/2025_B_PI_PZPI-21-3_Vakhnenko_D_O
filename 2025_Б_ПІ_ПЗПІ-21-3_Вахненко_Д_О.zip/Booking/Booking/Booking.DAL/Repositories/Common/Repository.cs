﻿using Booking.DAL.EF;
using Booking.DAL.Entities;
using Booking.DAL.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace Booking.DAL.Repositories.Common
{
    class Repository<TEntity> : BaseRepository, IRepository<TEntity> where TEntity : class
    {
        public Repository(IDbContextFactory<BookingDbContext> contextFactory)
            : base(contextFactory)
        {
        }

        public virtual async Task<List<TEntity>> GetAllAsync()
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().ToListAsync();
            }
        }

        public async Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicate).ToListAsync();
            }
        }

        public async Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate, string[] includeProperties)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicate).IncludeProperties(includeProperties).ToListAsync();
            }
        }

        public async Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>>[] predicates,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy,
            params string[] includeProperties)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicates)
                    .IncludeProperties(includeProperties).Order(orderBy).ToListAsync();
            }
        }

        public virtual async Task<List<TEntity>> GetAllAsync(int skipCount, int takeCount,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy,
            params Expression<Func<TEntity, bool>>[] predicates)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicates).Order(orderBy)
                .SkipItems(skipCount).TakeItems(takeCount).ToListAsync();
            }
        }

        public virtual async Task<List<TEntity>> GetAllAsync(int skipCount, int takeCount,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy,
            string[] includeProperties,
            params Expression<Func<TEntity, bool>>[] predicates)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicates).IncludeProperties(includeProperties)
                    .Order(orderBy).SkipItems(skipCount).TakeItems(takeCount).ToListAsync();
            }
        }

        public async Task<List<TEntity>> GetLatestByDateAsync(Expression<Func<TEntity, bool>> predicate, Expression<Func<TEntity, DateTime>> keySelector)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().Where(predicate).GroupBy(keySelector).OrderByDescending(g => g.Key)
                    .Take(1).Select(g => g.ToList()).FirstAsync();
            }
        }

        public async Task<TEntity> GetByIdAsync(int id)
        {
            TEntity? entity = null;
            using (var context = _contextFactory.CreateDbContext())
            {
                entity = await context.Set<TEntity>().FindAsync(id);
            }

            if (entity == null)
                throw new Exception($"Не знайдено запис з таким id: {id}");

            return entity;
        }

        public virtual async Task<TEntity> GetByIdAsync(int id, bool withAllProperties)
        {
            var entity = await GetByIdAsync(id);

            if (withAllProperties)
            {
                return await LoadAllRelatedEntitiesAsync(entity);
            }

            return entity;
        }

        public async Task<TEntity> GetByIdAsync(int id, params string[] includeProperties)
        {
            TEntity entity = await GetByIdAsync(id);
            return await LoadRelatedEntitiesAsync(entity, includeProperties);
        }

        public async Task<int> GetCountAsync(params Expression<Func<TEntity, bool>>[] predicates)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicates).CountAsync();
            }
        }

        public async Task<int> GetGroupsCountAsync<TKey>(Expression<Func<TEntity, bool>>[] predicates, Expression<Func<TEntity, TKey>> groupBy)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Set<TEntity>().AsQueryable().Filter(predicates).GroupBy(groupBy).CountAsync();
            }
        }

        public async Task<TEntity?> GetFirstOrDefaultAsync(Expression<Func<TEntity, bool>>? predicate = null)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                var querable = context.Set<TEntity>().AsQueryable();

                if (predicate != null)
                {
                    querable = querable.Filter(predicate);
                }

                return await querable.FirstOrDefaultAsync();
            }
        }

        public async Task<TEntity> InsertAsync(TEntity entity)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                context.Attach(entity);
                EntityEntry<TEntity> added = await context.Set<TEntity>().AddAsync(entity);
                await context.SaveChangesAsync();
                return added.Entity;
            }
        }

        public virtual async Task<TEntity> UpdateAsync(TEntity entityToUpdate)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                EntityEntry<TEntity> updated = context.Set<TEntity>().Update(entityToUpdate);
                await context.SaveChangesAsync();
                return updated.Entity;
            }
        }

        public async Task<TEntity> DeleteAsync(int id)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                TEntity? entityToDelete = await context.Set<TEntity>().FindAsync(id);

                if (entityToDelete == null)
                    throw new Exception($"Не знайдено запис з таким id: {id}");

                var deleted = context.Set<TEntity>().Remove(entityToDelete);
                await context.SaveChangesAsync();
                return deleted.Entity;
            }
        }

        public async Task<List<TEntity>> DeleteRangeAsync(Expression<Func<TEntity, bool>> predicate)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                var entitiesToDelete = await context.Set<TEntity>().Where(predicate).ToListAsync();
                context.Set<TEntity>().RemoveRange(entitiesToDelete);
                await context.SaveChangesAsync();
                return entitiesToDelete;
            }
        }

        protected async Task<TEntity> LoadAllRelatedEntitiesAsync(TEntity entity)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                context.Attach(entity);
                var referenceProperties = context.Entry(entity).References.ToList();
                foreach (var property in referenceProperties)
                {
                    if (!property.IsLoaded)
                    {
                        await context.Entry(entity).Reference(property.Metadata.Name).LoadAsync();
                    }
                }

                var referenceCollections = context.Entry(entity).Collections.ToList();
                foreach (var collection in referenceCollections)
                {
                    if (!collection.IsLoaded)
                    {
                        await context.Entry(entity).Collection(collection.Metadata.Name).LoadAsync();
                    }
                }

                return entity;
            }
        }

        protected async Task<TEntity> LoadRelatedEntitiesAsync(TEntity entity, params string[] includeProperties)
        {
            if (includeProperties.Length > 0)
            {
                using (var context = _contextFactory.CreateDbContext())
                {
                    context.Attach(entity);
                    var referenceProperties = context.Entry(entity).References.Select(r => r.Metadata.Name).ToList();
                    var referenceCollections = context.Entry(entity).Collections.Select(r => r.Metadata.Name).ToList();

                    foreach (string property in includeProperties)
                    {
                        if (referenceProperties.Contains(property))
                        {
                            await context.Entry(entity).Reference(property).LoadAsync();
                        }
                        else if (referenceCollections.Contains(property))
                        {
                            await context.Entry(entity).Collection(property).LoadAsync();
                        }
                    }
                }
            }

            return entity;
        }
    }
}
