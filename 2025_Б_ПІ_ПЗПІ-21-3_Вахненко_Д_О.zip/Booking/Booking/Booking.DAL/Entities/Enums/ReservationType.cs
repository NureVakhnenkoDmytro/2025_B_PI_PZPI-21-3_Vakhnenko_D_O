﻿using System.ComponentModel.DataAnnotations;

namespace Booking.DAL.Entities.Enums
{
    public enum ReservationType
    {
        [Display(Name = "Заброньовано")]
        Booked,
        [Display(Name = "Відмінено")]
        Canceled,
        [Display(Name = "Закінчено")]
        Finished
    }
}
