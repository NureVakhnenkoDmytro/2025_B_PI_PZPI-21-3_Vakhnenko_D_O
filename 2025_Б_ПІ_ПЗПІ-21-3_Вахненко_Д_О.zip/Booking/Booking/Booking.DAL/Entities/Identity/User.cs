﻿using Microsoft.AspNetCore.Identity;
using System.Collections.ObjectModel;

namespace Booking.DAL.Entities.Identity
{
    public class User : IdentityUser<int>
    {
        public virtual ICollection<UserRole> UserRoles { get; set; } = new Collection<UserRole>();

        public List<UserGroup> UserGroups { get; set; } = new();
    }
}
