﻿using Microsoft.AspNetCore.Identity;

namespace Booking.DAL.Entities.Identity
{
    public class RoleClaim : IdentityRoleClaim<int>
    {
    }
}
