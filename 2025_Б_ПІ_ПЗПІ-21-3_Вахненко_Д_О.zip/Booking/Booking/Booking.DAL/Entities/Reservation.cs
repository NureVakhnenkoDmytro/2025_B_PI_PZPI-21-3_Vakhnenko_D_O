﻿using Booking.DAL.Entities.Common;
using Booking.DAL.Entities.Enums;
using Booking.DAL.Entities.Identity;
using System.ComponentModel.DataAnnotations;

namespace Booking.DAL.Entities
{
    [Display(Name = "Бронювання")]
    public class Reservation : BaseEntity
    {
        [Display(Name = "Тип бронювання")]
        public ReservationType Type { get; set; }

        [Display(Name = "Дата створення заявки")]
        public DateTime Date { get; set; } = DateTime.Now;

        [Display(Name = "Початок оренди")]
        public DateTime Start { get; set; } = DateTime.Now;

        [Display(Name = "Кінець оренди")]
        public DateTime End { get; set; } = DateTime.Now.AddDays(1);

        [Display(Name = "Помешкання")]
        public int? AccommodationId { get; set; }

        [Display(Name = "Помешкання")]
        public Accommodation? Accommodation { get; set; }

        [Display(Name = "Орендар")]
        public int UserId { get; set; }

        [Display(Name = "Орендар")]
        public User? User { get; set; }

        public decimal Cost => (decimal)(End - Start).TotalHours * (Accommodation?.PricePerHour ?? 0);

        public decimal CostByDay => (Accommodation?.PricePerHour ?? 0) * 24;
    }
}
