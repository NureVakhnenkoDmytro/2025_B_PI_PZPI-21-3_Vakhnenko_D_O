﻿using Booking.DAL.Entities.Common;
using Booking.DAL.Entities.Identity;

namespace Booking.DAL.Entities
{
    public class UserGroup : BaseEntity
    {
        public int UserId { get; set; }

        public User? User { get; set; }

        public int CatalogId { get; set; }

        public Group? Catalog { get; set; }
    }
}
