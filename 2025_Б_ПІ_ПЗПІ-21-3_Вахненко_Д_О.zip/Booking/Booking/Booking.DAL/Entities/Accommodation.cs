﻿using Booking.DAL.Entities.Common;
using Booking.DAL.Entities.Identity;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Booking.DAL.Entities
{
    [Display(Name = "Помешкання")]
    public class Accommodation : BaseEntity
    {
        [Display(Name = "Назва")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Опис")]
        public string Description { get; set; } = string.Empty;

        [Display(Name = "Ціна за годину")]
        [Column(TypeName = "money")]
        [Range(0, 922337203685477.58, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public decimal PricePerHour { get; set; }

        [Display(Name = "Доступна для оренди з")]
        public DateTime LeaseStart { get; set; } = DateTime.Now;

        [Display(Name = "Доступна для оренди до")]
        public DateTime LeaseEnd { get; set; } = DateTime.Now.AddDays(5);

        [Display(Name = "Творець")]
        public int UserId { get; set; }

        [Display(Name = "Творець")]
        public User? User { get; set; }

        public List<Feature> Features { get; set; } = new();

        public List<Reservation> Reservations { get; set; } = new();
    }
}
