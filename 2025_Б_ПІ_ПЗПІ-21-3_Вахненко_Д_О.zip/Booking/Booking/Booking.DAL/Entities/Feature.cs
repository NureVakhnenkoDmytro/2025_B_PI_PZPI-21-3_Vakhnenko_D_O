﻿using Booking.DAL.Entities.Common;

namespace Booking.DAL.Entities
{
    public class Feature : BaseEntity
    {
        public int AccommodationId { get; set; }

        public Accommodation? Accommodation { get; set; }

        public int CatalogId { get; set; }

        public Catalog? Catalog { get; set; }
    }
}
