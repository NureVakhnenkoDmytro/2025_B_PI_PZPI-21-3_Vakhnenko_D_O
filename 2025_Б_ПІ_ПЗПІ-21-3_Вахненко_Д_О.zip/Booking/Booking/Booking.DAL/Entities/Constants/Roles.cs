﻿namespace Booking.DAL.Entities.Constants
{
    public static class Roles
    {
        public const string Admin = "admin";
        public const string User = "user";

        public static List<string> AllRoles = new List<string> { Admin, User };
    }
}
