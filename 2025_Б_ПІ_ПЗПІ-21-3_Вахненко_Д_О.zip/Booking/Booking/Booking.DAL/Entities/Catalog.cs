﻿using Booking.DAL.Entities.Common;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Booking.DAL.Entities
{
    public class Catalog : BaseEntity
    {
        [Display(Name = "Назва")]
        [MaxLength(255, ErrorMessage = "{0} має бути коротшим за {1} символів.")]
        public string Name { get; set; } = null!;

        [MaxLength(255)]
        public string Discriminator { get; set; } = null!;

        public int? ParentId { get; set; }

        public static List<Catalog> GetAllHeirsInstances(params Type[] skipTypes)
        {
            Type type = typeof(Catalog);
            var heirs = Assembly.GetAssembly(type).GetTypes().Where(t => !skipTypes.Any(st => st == t) && t.IsSubclassOf(type));

            var catalogs = new List<Catalog>();

            foreach (var heir in heirs)
            {
                var catalog = (Catalog)Activator.CreateInstance(heir)!;
                catalog.Discriminator = heir.Name;
                catalogs.Add(catalog);
            }

            return catalogs;
        }

        public static Catalog CreateByDiscriminator(string discriminator)
        {
            Type type = typeof(Catalog);
            var heir = Assembly.GetAssembly(type)!.GetTypes().FirstOrDefault(t => t.IsSubclassOf(type) && type.Name == discriminator);

            if (heir != null)
            {
                var catalog = (Catalog)Activator.CreateInstance(heir)!;
                catalog.Discriminator = discriminator;
                return catalog;
            }

            return new Catalog();
        }
    }

    public class Parent : Catalog //<TChild> : Catalog where TChild : Catalog
    {
        //public Type ChildType => typeof(TChild);

        //public List<TChild> Children { get; set; } = new();
        
        public List<Child> Children { get; set; } = new();
    }

    public class Child : Catalog//<TParent> : Catalog where TParent : Catalog
    {
        //public Type ParentType => typeof(TParent);

        public Parent Parent { get; set; } = null!;
    }

    [Display(Name = "Країна")]
    public class Country : Parent//<Region> 
    { }

    [Display(Name = "Область")]
    public class Region : Child//<Country> 
    { }

    [Display(Name = "Відстань від центру")]
    public class DistanceFromCenter : Catalog { }

    [Display(Name = "Зручності")]
    public class Amenities : Catalog { }

    [Display(Name = "Зручності у номері")]
    public class RoomAmenities : Catalog { }

    [Display(Name = "Зручності у помешканні для осіб з інвалідністю")]
    public class AmenitiesForPersonsWithDisabilities : Catalog { }

    [Display(Name = "Політика скасування")]
    public class CancellationPolicy : Catalog { }

    [Display(Name = "Харчування")]
    public class Food : Catalog { }

    [Display(Name = "Тип помешкання")]
    public class TypeAccommodation : Catalog { }

    [Display(Name = "Визначні місця")]
    public class Attractions : Catalog { }

    [Display(Name = "Тип ліжка")]
    public class BedType : Catalog { }

    [Display(Name = "Мережі")]
    public class Network : Catalog { }

    [Display(Name = "Групи користувачів")]
    public class Group : Catalog { }
}
