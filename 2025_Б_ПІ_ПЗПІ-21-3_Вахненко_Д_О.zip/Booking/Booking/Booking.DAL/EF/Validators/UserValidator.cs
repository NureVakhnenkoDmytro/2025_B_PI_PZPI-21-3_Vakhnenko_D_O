﻿using Booking.DAL.Entities.Identity;
using Microsoft.AspNetCore.Identity;

namespace Booking.DAL.EF.Validators
{
    public class UserValidator : IUserValidator<User>
    {
        public Task<IdentityResult> ValidateAsync(UserManager<User> manager, User user)
        {
            return Task.FromResult(IdentityResult.Success);
        }
    }
}
