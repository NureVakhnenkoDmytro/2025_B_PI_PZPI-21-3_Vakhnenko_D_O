﻿using Booking.DAL.Entities;
using Booking.DAL.Entities.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Booking.DAL.EF
{
    public class BookingDbContext : IdentityDbContext<User, Role, int, 
        UserClaim, UserRole, UserLogin, RoleClaim, UserToken>
    {
        public DbSet<Accommodation> Accommodations { get; set; } = null!;
        public DbSet<Feature> Features { get; set; } = null!;
        public DbSet<Reservation> Reservations { get; set; } = null!;

        public DbSet<Catalog> Catalogs { get; set; } = null!;
        public DbSet<Country> Countries { get; set; } = null!;
        public DbSet<Region> Regions { get; set; } = null!;
        public DbSet<DistanceFromCenter> DistanceFromCenters { get; set; } = null!;
        public DbSet<Amenities> Amenities { get; set; } = null!;
        public DbSet<RoomAmenities> RoomAmenities { get; set; } = null!;
        public DbSet<AmenitiesForPersonsWithDisabilities> AmenitiesForPersonsWithDisabilities { get; set; } = null!;
        public DbSet<CancellationPolicy> CancellationPolicies { get; set; } = null!;
        public DbSet<Food> Foods { get; set; } = null!;
        public DbSet<TypeAccommodation> TypeAccommodations { get; set; } = null!;
        public DbSet<Attractions> Attractions { get; set; } = null!;
        public DbSet<BedType> BedTypes { get; set; } = null!;
        public DbSet<Network> Networks { get; set; } = null!;
        public DbSet<Group> Groups { get; set; } = null!;

        public DbSet<UserGroup> UserGroups { get; set; } = null!;

        public BookingDbContext(DbContextOptions<BookingDbContext> options)
            : base(options)
        {
            //uncomment if you want automatic update database
            //Database.Migrate();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<User>(b =>
            {
                b.HasMany(e => e.UserRoles).WithOne(e => e.User).HasForeignKey(ur => ur.UserId).IsRequired();
            });

            builder.Entity<Role>(b =>
            {
                b.HasMany(e => e.UserRoles).WithOne(e => e.Role).HasForeignKey(ur => ur.RoleId).IsRequired();
            });

            //Auto Include Properties
            builder.Entity<Accommodation>().Navigation(a => a.User).AutoInclude();
            builder.Entity<Accommodation>().Navigation(a => a.Features).AutoInclude();
            builder.Entity<Accommodation>().Navigation(a => a.Reservations).AutoInclude();

            builder.Entity<Reservation>().Navigation(r => r.Accommodation).AutoInclude();
            builder.Entity<Reservation>().Navigation(r => r.User).AutoInclude();

            builder.Entity<User>().Navigation(u => u.UserGroups).AutoInclude();

            AddDefaultAdmin(builder);
        }

        private void AddDefaultAdmin(ModelBuilder builder)
        {
            var adminRole = new Role()
            {
                Id = 1,
                ConcurrencyStamp = "c30f2907-b1df-49cd-9bc5-0efa039ba9ae",
                Name = Entities.Constants.Roles.Admin,
                NormalizedName = Entities.Constants.Roles.Admin.ToUpper()
            };

            var userRole = new Role()
            {
                Id = 2,
                ConcurrencyStamp = "c30f2907-b1df-49cd-9bc5-0efa039ba9aa",
                Name = Entities.Constants.Roles.User,
                NormalizedName = Entities.Constants.Roles.User.ToUpper()
            };

            var admin = new User()
            {
                Id = 1,
                UserName = "admin@gmail.com",
                NormalizedUserName = "ADMIN@GMAIL.COM",
                Email = "admin@gmail.com",
                NormalizedEmail = "ADMIN@GMAIL.COM",
                PasswordHash = "AQAAAAEAACcQAAAAEOvStY69qPpyG3M1Jzr6D0W0Vk0YlZeK1Pvwo+/4MDhl1N+513DvpoJ7iKZPjHCrlQ==", //12345678Aa!
                SecurityStamp = "OGV2JH6BM27RUQFSQDOXDM2WO7EN4F7S",
                ConcurrencyStamp = "562428c2-5d6b-40a9-a0a6-0665802ede1d"
            }; 
            
            var adminWithRole = new UserRole()
            {
                RoleId = adminRole.Id,
                UserId = admin.Id
            };

            builder.Entity<Role>().HasData(adminRole);
            builder.Entity<Role>().HasData(userRole);

            builder.Entity<User>().HasData(admin);
            builder.Entity<UserRole>().HasData(adminWithRole);
        }
    }
}
