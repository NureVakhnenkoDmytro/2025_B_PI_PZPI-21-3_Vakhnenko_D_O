﻿using Booking.DAL.EF;
using Booking.DAL.Entities;
using Booking.DAL.Entities.Identity;
using Booking.DAL.Repositories;
using Booking.DAL.Repositories.Common;
using Microsoft.EntityFrameworkCore;

namespace Booking.DAL.UnitOfWork.Implementations
{
    class UnitOfWork : IUnitOfWork
    {
        private readonly IDbContextFactory<BookingDbContext> _contextFactory;

        public IRepository<Catalog> Catalogs => new Repository<Catalog>(_contextFactory);

        public IRepository<Accommodation> Accommodations => new Repository<Accommodation>(_contextFactory);

        public IRepository<Feature> Features => new Repository<Feature>(_contextFactory);

        public IRepository<Reservation> Reservations => new Repository<Reservation>(_contextFactory);

        public IRepository<User> Users => new Repository<User>(_contextFactory);

        public UnitOfWork(IDbContextFactory<BookingDbContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public TRepository GetTRepository<TRepository>()
        {
            Type tRepository = typeof(TRepository);
            var repositoryPI = this.GetType().GetProperties().FirstOrDefault(t => t.PropertyType == tRepository);

            if (repositoryPI == null)
                throw new Exception("TRepository not exist");

            return (TRepository)repositoryPI.GetValue(this, null)!;
        }
    }
}
