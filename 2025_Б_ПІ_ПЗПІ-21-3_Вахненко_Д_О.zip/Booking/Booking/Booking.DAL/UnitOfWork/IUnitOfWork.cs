﻿using Booking.DAL.Entities;
using Booking.DAL.Entities.Identity;
using Booking.DAL.Repositories;

namespace Booking.DAL.UnitOfWork
{
    public interface IUnitOfWork
    {
        IRepository<Catalog> Catalogs { get; }

        IRepository<Accommodation> Accommodations { get; }

        IRepository<Feature> Features { get; }

        IRepository<Reservation> Reservations { get; }

        IRepository<User> Users { get; }

        TRepository GetTRepository<TRepository>();
    }
}
