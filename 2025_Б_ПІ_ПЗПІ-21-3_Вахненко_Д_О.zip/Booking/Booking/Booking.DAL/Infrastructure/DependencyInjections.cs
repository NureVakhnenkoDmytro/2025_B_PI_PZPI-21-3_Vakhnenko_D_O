﻿using Booking.DAL.EF;
using Booking.DAL.EF.Localizers;
using Booking.DAL.EF.Validators;
using Booking.DAL.Entities.Identity;
using Booking.DAL.UnitOfWork;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Booking.DAL.Infrastructure
{
    public static class DependencyInjections
    {
        public static IdentityBuilder ConfigureDAL(this IServiceCollection services, string connectionString)
        {
            return services
                .AddDbContextFactory<BookingDbContext>(options => options.UseSqlServer(connectionString))
                .AddScoped<IUnitOfWork, UnitOfWork.Implementations.UnitOfWork>()
                .ConfigureIdentity();
        }

        private static IdentityBuilder ConfigureIdentity(this IServiceCollection services)
        {
            return services.AddIdentity<User, Role>(options =>
            {
                options.SignIn.RequireConfirmedAccount = false;
            })
                .AddDefaultTokenProviders()
                .AddErrorDescriber<LocalizedIdentityErrorDescriber>()
                .AddEntityFrameworkStores<BookingDbContext>()
                .AddUserValidator<UserValidator>()
                .AddPasswordValidator<PasswordValidator>();
        }
    }
}
