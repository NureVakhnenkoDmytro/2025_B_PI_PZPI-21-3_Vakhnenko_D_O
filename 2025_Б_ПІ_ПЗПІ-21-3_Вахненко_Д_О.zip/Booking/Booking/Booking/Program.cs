using Booking.ViewServices;
using Booking.ViewServices.Implementations;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server;
using Microsoft.EntityFrameworkCore;

try
{
    var builder = WebApplication.CreateBuilder(args);

    var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
    builder.Services.ConfigureBLL(connectionString);

    //builder.Services.Configure<CRMParserOptions>(builder.Configuration.GetSection("CRMParserOptions"));

    builder.Services.AddAuthenticationCore();
    builder.Services.AddScoped<AuthenticationStateProvider, ServerAuthenticationStateProvider>();
    builder.Services.AddRazorPages();
    builder.Services.AddServerSideBlazor();

    AddViewServices(builder.Services);
    builder.Services.AddHostedServices();

    builder.Services.AddDatabaseDeveloperPageExceptionFilter();
    builder.Services.AddHttpContextAccessor();
    builder.Services.AddControllersWithViews();

    builder.Services.AddAuthentication().AddGoogle(googleOptions =>
    {
        googleOptions.ClientId = builder.Configuration["Authentication:Google:ClientId"];
        googleOptions.ClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
    });

    var app = builder.Build();

    if (app.Environment.IsDevelopment())
    {
        app.UseMigrationsEndPoint();
    }
    else
    {
        app.UseExceptionHandler("/Error");
        app.UseHsts();
    }

    app.UseHttpsRedirection();
    app.UseRouting();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseStaticFiles();
    app.MapWhen(ctx => ctx.Request.Path.StartsWithSegments("/_framework/blazor.server.js"), subApp => subApp.UseStaticFiles());

    app.MapControllers();
    app.MapBlazorHub();
    app.MapFallbackToPage("/_Host");
    app.UseEndpoints(endpoints =>
    {
        endpoints.MapControllerRoute(
            name: "default",
            pattern: "{controller=DashBoard}/{action=Index}/{id?}");
    });

    app.Run();
}
catch (Exception exception)
{
}

static void AddViewServices(IServiceCollection services)
{
    services.AddScoped<ITitleService, TitleService>();
    services.AddScoped<ICustomJSRuntime, CustomJSRuntime>();
    services.AddScoped<INotificationService, NotificationService>();
    services.AddSingleton<IErrorTranslator, ErrorTranslator>();
}