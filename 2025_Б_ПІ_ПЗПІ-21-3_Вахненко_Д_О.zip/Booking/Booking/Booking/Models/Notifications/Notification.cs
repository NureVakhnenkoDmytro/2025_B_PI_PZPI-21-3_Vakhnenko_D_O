﻿namespace Booking.Models.Notifications
{
    public class Notification
    {
        private const int _secondsToLive = 3;

        public Guid Id { get; init; }
        public string Title { get; init; }
        public string Message { get; init; }
        public MessageColor MessageColor { get; init; }
        public DateTimeOffset TimeToBurn { get; init; }
        public DateTimeOffset Posted { get; init; }
        public TimeSpan ElapsedTime => Posted - DateTimeOffset.Now;
        public bool IsBurnt => TimeToBurn < DateTimeOffset.Now;

        public string ElapsedTimeText
        {
            get
            {
                return ElapsedTime.Seconds > 60
                    ? $"{-ElapsedTime.Minutes} хвилин тому"
                    : $"{-ElapsedTime.Seconds} секунд тому";
            }
        }

        public Notification()
        {
            Id = Guid.NewGuid();
            Title = string.Empty;
            Message = string.Empty;
            MessageColor = MessageColor.Primary;
            TimeToBurn = DateTimeOffset.Now.AddSeconds(_secondsToLive);
            Posted = DateTimeOffset.Now;
        }

        public Notification(string title, string message, MessageColor messageColor)
            : this()
        {
            Title = title;
            Message = message;
            MessageColor = messageColor;
        }
    }
}
