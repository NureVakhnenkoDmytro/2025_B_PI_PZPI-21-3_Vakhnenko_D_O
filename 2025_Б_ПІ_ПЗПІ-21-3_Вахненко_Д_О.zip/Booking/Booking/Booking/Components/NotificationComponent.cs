﻿using Booking.Models.Notifications;
using Booking.ViewServices;
using Microsoft.AspNetCore.Components;

namespace Booking.Components
{
    public abstract class NotificationComponent : BaseComponent
    {
        private string _title;

        [Inject] private INotificationService NotificationService { get; set; } = null!;
        [Inject] protected IErrorTranslator ErrorTranslator { get; set; } = null!;

        protected string NotificationTitle
        {
            get { return _title; }
            set { _title = value; }
        }

        public NotificationComponent()
        {
            _title = string.Empty;
        }

        public NotificationComponent(string title)
        {
            _title = title;
        }

        public void AddSuccess(string message, string title = "")
        {
            AddNotification(title, message, MessageColor.Success);
        }

        public void AddWarning(string message, string title = "")
        {
            AddNotification(title, ErrorTranslator[message], MessageColor.Warning);
        }

        public void AddError(Exception ex)
        {
            AddNotification(string.Empty, ErrorTranslator[ex], MessageColor.Danger);
        }

        public void AddInfo(string message, string title = "")
        {
            AddNotification(title, message, MessageColor.Info);
        }

        public void AddPrimary(string message, string title = "")
        {
            AddNotification(title, message, MessageColor.Primary);
        }

        public void AddSecondary(string message, string title = "")
        {
            AddNotification(title, message, MessageColor.Secondary);
        }

        public void AddDark(string message, string title = "")
        {
            AddNotification(title, message, MessageColor.Dark);
        }

        public void AddLight(string message, string title = "")
        {
            AddNotification(title, message, MessageColor.Light);
        }

        private void AddNotification(string title, string message, MessageColor messageColor)
        {
            if (string.IsNullOrEmpty(title))
                title = NotificationTitle;

            NotificationService.AddNotification(new Notification(title, message, messageColor));
        }
    }
}
