﻿namespace Booking.Components.Enums
{
    public enum ModalType
    {
        None,
        AddModal,
        EditModal,
        AddOrEditModal,
        DeleteModal
    }
}
