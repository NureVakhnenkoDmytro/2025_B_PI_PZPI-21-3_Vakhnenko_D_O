using Booking.BLL.Managers;
using Booking.DAL.Entities.Identity;
using Booking.ViewServices;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;

namespace Booking.Components
{
    public class BaseComponent : ComponentBase
    {
        [Inject] protected UserManager UserManager { get; set; } = null!;
        [Inject] protected NavigationManager NavigationManager { get; set; } = null!;
        [Inject] protected ITitleService TitleService { get; set; } = null!;
        [Inject] protected ICustomJSRuntime JsRuntime { get; set; } = null!;
        [CascadingParameter] public Task<AuthenticationState> AuthState { get; set; } = null!;

        public string Title 
        { 
            get { return TitleService?.Title ?? string.Empty; }
            set { TitleService.Title = value; } 
        }

        protected async Task<User> GetCurrentUserAsync()
        {
            try
            {
                var authState = await AuthState;
                return await UserManager.GetUserAsync(authState.User);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
