﻿using Microsoft.AspNetCore.Components.Forms;

namespace Booking.Components
{
    public abstract class FormComponent<TModel> : NotificationComponent where TModel : class, new()
    {
        public TModel Model { get; set; } = null!;

        protected virtual bool Edit { get; }

        public FormComponent()
        {
            Model = new();
        }

        public FormComponent(string title)
            : base(title)
        {
            Model = new();
        }

        public virtual Task OnClickEdit()
        {
            return Task.CompletedTask;
        }

        public virtual async Task SaveAsync(EditContext context)
        {
            try
            {
                if (Edit)
                {
                    await EditAsync();
                }
                else
                {
                    await AddAsync();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected virtual async Task AddAsync()
        {
            try
            {
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }

        protected virtual async Task EditAsync()
        {
            try
            {
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }
    }
}
