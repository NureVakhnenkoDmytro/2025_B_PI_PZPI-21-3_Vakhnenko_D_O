﻿using Booking.Models.Notifications;
using Booking.ViewServices;
using Microsoft.AspNetCore.Components;

namespace Booking.Shared.Common
{
    public class NotificationsModel : ComponentBase, IDisposable
    {
        [Inject] public INotificationService NotificationService { get; set; } = null!;

        public string NotificationCss(Notification notification)
        {
            var colour = Enum.GetName(typeof(MessageColor), notification.MessageColor)?.ToLower();
            return notification.MessageColor switch
            {
                MessageColor.Light => "bg-light",
                _ => $"bg-{colour} text-white"
            };
        }

        public void ClearNotification(Notification notification)
        {
            NotificationService.ClearNotification(notification);
        }

        protected override void OnInitialized()
        {
            NotificationService.NotificationsChanged += ToastChanged;
            NotificationService.NotificationTimerElapsed += ToastChanged;
        }

        public void Dispose()
        {
            NotificationService.NotificationsChanged -= ToastChanged;
            NotificationService.NotificationTimerElapsed -= ToastChanged;
            GC.SuppressFinalize(this);
        }

        private void ToastChanged(object? sender, EventArgs e)
        {
            InvokeAsync(StateHasChanged);
        }
    }
}
