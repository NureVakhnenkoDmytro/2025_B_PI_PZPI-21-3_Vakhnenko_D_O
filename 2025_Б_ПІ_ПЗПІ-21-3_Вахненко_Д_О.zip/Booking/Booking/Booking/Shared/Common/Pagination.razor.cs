﻿using Booking.Infrastructure;
using Microsoft.AspNetCore.Components;

namespace Booking.Shared.Common
{
    public class PaginationComponent : ComponentBase
    {
        private const int _totalShowPages = 9;

        [Parameter] public int TotalPages { get; set; }
        [Parameter] public int PageNumber { get; set; }
        [Parameter] public EventCallback<int> OnPageChanged { get; set; }

        public List<int> ShowPages { get; private set; }

        public PaginationComponent()
        {
            ShowPages = new();
        }

        public async Task OnPageChangeAsync(int pageNumber)
        {
            await OnPageChanged.InvokeDelegateAsync(pageNumber);
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
            ShowPages = GetShowPages();
        }

        private List<int> GetShowPages()
        {
            List<int> showPages = new();
            if (TotalPages > 1)
            {
                if (PageNumber > 1)
                {
                    for (int i = PageNumber - 1; i < PageNumber && i > 0 && showPages.Count < (_totalShowPages - 1) / 2; i--)
                    {
                        showPages.Add(i);
                    }
                }

                if (PageNumber <= TotalPages)
                {
                    for (int i = PageNumber; i <= TotalPages && showPages.Count < _totalShowPages; i++)
                    {
                        showPages.Add(i);
                    }
                }
            }

            return showPages.OrderBy(x => x).ToList();
        }
    }
}
