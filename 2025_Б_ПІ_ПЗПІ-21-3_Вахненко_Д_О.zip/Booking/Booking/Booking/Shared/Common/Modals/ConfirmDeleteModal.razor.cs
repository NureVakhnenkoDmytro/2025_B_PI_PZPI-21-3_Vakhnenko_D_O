﻿using Microsoft.AspNetCore.Components;
using Booking.Components;
using Booking.Components.Enums;
using Booking.Infrastructure;
using Booking.ViewServices;

namespace Booking.Shared.Common.Modals
{
    public class ConfirmDeleteModalModel : NotificationComponent
    {
        private string _defaultContent = "Ви дійсно хочете видалити?";
        private string CurrentModalId { get; init; } = ModalType.DeleteModal.ToString();

        [Inject] public ICustomJSRuntime JsRuntime { get; set; } = null!;
        [Parameter] public string? Content { get; set; } = null;
        [Parameter] public bool Show { get; set; }
        [Parameter] public EventCallback OnСonfirmed { get; set; }
        [Parameter] public EventCallback<string> OnCanceled { get; set; }

        public async Task OnClickCancelAsync()
        {
            try
            {
                await OnCanceled.InvokeDelegateAsync(CurrentModalId);
                await CloseModalAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnClickDeleteAsync()
        {
            try
            {
                await OnСonfirmed.InvokeDelegateAsync();
                await CloseModalAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                if (Content == null)
                {
                    Content = _defaultContent;
                }

                if (Show)
                {
                    await OpenModalAsync();
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private async Task OpenModalAsync()
        {
            try
            {
                await JsRuntime.OpenModalAsync(CurrentModalId);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private async Task CloseModalAsync()
        {
            try
            {
                await JsRuntime.CloseModalAsync(CurrentModalId);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
