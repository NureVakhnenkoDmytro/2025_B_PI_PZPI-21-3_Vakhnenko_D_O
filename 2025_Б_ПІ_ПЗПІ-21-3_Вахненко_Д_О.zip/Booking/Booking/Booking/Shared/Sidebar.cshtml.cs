﻿using Booking.DAL.Entities.Constants;
using Booking.DAL.Entities.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Booking.Pages.Shared.Layout
{
    public class SidebarModel : PageModel
    {
        private readonly string _currentRole;
        private readonly User? _currentUser;

        public bool IsAuthorized => _currentUser != null;
        public bool IsAdmin => _currentRole == Roles.Admin;
        public bool IsUser => _currentRole == Roles.User;

        public SidebarModel(User? user, string role)
        {
            _currentUser = user;
            _currentRole = role;
        }

        public static SidebarModel Default()
        {
            return new SidebarModel(null, string.Empty);
        }
    }
}
