﻿using Booking.ViewServices;
using Microsoft.AspNetCore.Components;

namespace Booking.Shared
{
    public class TitleMetaModel : ComponentBase
    {
        [Inject] protected ITitleService TitleService { get; set; } = null!;

        protected override void OnInitialized()
        {
            TitleService.PropertyChanged += PropertyChanged;
        }

        private void PropertyChanged(object? sender, EventArgs e)
        {
            StateHasChanged();
        }
    }
}
