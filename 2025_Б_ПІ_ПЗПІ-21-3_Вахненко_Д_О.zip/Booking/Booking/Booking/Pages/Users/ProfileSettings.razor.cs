﻿using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities.Identity;
using Microsoft.AspNetCore.Components;

namespace Booking.Pages.Users
{
    public class ProfileSettingsModel : NotificationComponent
    {
        [Inject] private IUserService UserService { get; set; } = null!;

        public User User { get; set; } = new();

        public ProfileSettingsModel()
            : base("Користувач")
        {
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                Title = "Налаштування";
                User = await GetCurrentUserAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
