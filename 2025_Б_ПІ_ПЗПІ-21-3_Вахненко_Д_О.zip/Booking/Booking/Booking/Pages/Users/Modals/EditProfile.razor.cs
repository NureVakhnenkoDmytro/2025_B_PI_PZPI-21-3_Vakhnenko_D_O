﻿using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities.Identity;
using Booking.Infrastructure;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;

namespace Booking.Pages.Users.Modals
{
    public class EditProfileModel : FormComponent<User>
    {
        [Inject] public IUserService UserService { get; set; } = null!;
        [Parameter] public User User { get; set; } = null!;
        [Parameter] public EventCallback<User> OnUserChanged { get; set; }

        public string UserRole { get; private set; } = string.Empty;

        protected override bool Edit => User.Id != 0;

        public EditProfileModel(): base("Редагування профілю") { }

        public void OnChangeUserGroup(int userGroupId)
        {
            if (User.UserGroups.Any(f => f.CatalogId == userGroupId))
            {
                User.UserGroups.Remove(User.UserGroups.First(f => f.CatalogId == userGroupId));
            }
            else
            {
                User.UserGroups.Add(new DAL.Entities.UserGroup()
                {
                    CatalogId = userGroupId
                });
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                UserRole = await UserManager.GetRoleAsync(User);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public override async Task SaveAsync(EditContext context)
        {
            try
            {
                AddInfo("Збереження профілю...");
                await base.SaveAsync(context);
                AddSuccess("Профіль успішно змінено.");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task AddAsync()
        {
            try
            {
                User = await UserService.CreateAsync(User);
                await base.AddAsync();
                await OnUserChanged.InvokeDelegateAsync(User);
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }

        protected override async Task EditAsync()
        {
            try
            {
                User = await UserService.UpdateAsync(User);
                await base.EditAsync();
                await OnUserChanged.InvokeDelegateAsync(User);
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }
    }
}
