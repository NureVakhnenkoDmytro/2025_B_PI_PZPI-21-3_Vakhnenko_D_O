﻿using Booking.BLL.Managers;
using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities.Identity;
using Booking.Infrastructure;
using Microsoft.AspNetCore.Components;

namespace Booking.Pages.Users.Modals
{
    public class ChangeRoleModel : NotificationComponent
    {
        [Inject] public RoleManager RoleManager { get; set; } = null!;
        [Inject] public IUserService UserService { get; set; } = null!;

        [Parameter] public User User { get; set; } = null!;
        [Parameter] public EventCallback<string> OnRoleChanged { get; set; }

        public List<string> Roles { get; private set; }
        public string CurrentRole { get; private set; }
        public string SelectedRole { get; set; }

        public ChangeRoleModel()
            : base("Зміна ролі")
        {
            Roles = DAL.Entities.Constants.Roles.AllRoles;
            CurrentRole = string.Empty;
            SelectedRole = string.Empty;
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                CurrentRole = await UserManager.GetRoleAsync(User);
                SelectedRole = CurrentRole;
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task SaveRoleAsync()
        {
            try
            {
                AddInfo("Роль змінюється...");
                User = await UserManager.FindByEmailAsync(User.Email);
                await UserManager.SetRoleAsync(User, SelectedRole);
                CurrentRole = SelectedRole;
                AddSuccess($"Змінено роль користувача {User.UserName} на {SelectedRole}.");
                await OnRoleChanged.InvokeDelegateAsync(CurrentRole);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
