﻿using Booking.BLL.Models.Filters;
using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities;
using Booking.DAL.Entities.Constants;
using Booking.DAL.Entities.Enums;
using Microsoft.AspNetCore.Components;

namespace Booking.Pages
{
    public class IndexComponent : ItemsListComponent<Accommodation, AccommodationFilter>
    {
        [Inject] public IAccommodationService AccommodationService { get; set; } = null!;
        [Inject] public IReservationService ReservationService { get; set; } = null!;

        public List<IGrouping<string, Catalog>> CatalogGroupsByDiscriminator
        {
            get
            {
                var grouped = ST.Catalogs.GroupBy(c => c.Discriminator).Where(g => g.Count() > 0);

                if (_currentRole == Roles.User)
                {
                    grouped = grouped.Where(g => g.Key != nameof(Group));
                }

                return grouped.OrderBy(g => g.Key).ToList();
            }
        }

        public IndexComponent() 
            : base("Помешкання")
        {
            Filter.LeaseStart = DateTime.Now.Date;
            Filter.LeaseEnd = DateTime.Now.Date.AddDays(5);
        }

        public decimal GetCost(decimal pricePerHour)
        {
            var hours = (decimal)((Filter.LeaseEnd - Filter.LeaseStart)?.TotalHours ?? 0);
            return hours * pricePerHour;
        }

        public Task OnChangeFeature(int catalogId)
        {
            if (Filter.Features.Any(f => f == catalogId))
            {
                Filter.Features.Remove(Filter.Features.First(f => f == catalogId));
            }
            else
            {
                Filter.Features.Add(catalogId);
            }

            return OnFilterChanged();
        }

        public async Task OnClickReservationAsync(Accommodation accommodation)
        {
            try
            {
                var reservation = await ReservationService.CreateAsync(new Reservation()
                {
                    AccommodationId = accommodation.Id,
                    UserId = _currentUser.Id,
                    Start = Filter.LeaseStart!.Value,
                    End = Filter.LeaseEnd!.Value,
                    Type = ReservationType.Booked
                });

                accommodation.Reservations.Add(reservation);
                AddSuccess("Успішно заброньовано.");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnClickCancelReservationAsync(Reservation reservation)
        {
            try
            {
                reservation.Type = ReservationType.Canceled;
                reservation = await ReservationService.UpdateAsync(reservation);
                await LoadItemsAsync();
                AddSuccess("Бронювання успішно скасовано.");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnClickDeleteAsync(int accommodationId)
        {
            try
            {
                await AccommodationService.DeleteAsync(accommodationId);
                await LoadItemsAsync();
                AddSuccess("Успішно видалено.");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                await base.OnInitializedAsync();

                if (_currentRole == Roles.User)
                {
                    Filter.UserGroups = _currentUser.UserGroups.Select(u => u.CatalogId).ToList();
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task LoadItemsAsync()
        {
            try
            {
                ItemsList = await AccommodationService.FindByFilterAsync(Filter);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
