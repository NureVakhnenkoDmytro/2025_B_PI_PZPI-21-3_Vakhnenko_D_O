﻿using Booking.BLL.Models.Filters;
using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities;
using Booking.DAL.Entities.Constants;
using Booking.DAL.Entities.Enums;
using Microsoft.AspNetCore.Components;

namespace Booking.Pages
{
    public class ReservationsComponent : ItemsListComponent<Reservation, ReservationFilter>
    {
        [Inject] public IReservationService ReservationService { get; set; } = null!;

        public ReservationsComponent() 
            : base("Бронювання")
        {
        }

        public async Task OnClickChangeReservationTypeAsync(Reservation reservation, ReservationType type)
        {
            try
            {
                reservation.Type = type;
                reservation = await ReservationService.UpdateAsync(reservation);
                await LoadItemsAsync();
                AddSuccess("Бронювання успішно скасовано.");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                _currentUser = await GetCurrentUserAsync();
                string currentRole = await UserManager.GetRoleAsync(_currentUser);

                if (currentRole == Roles.User)
                {
                    Filter.UserId = _currentUser.Id;
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task LoadItemsAsync()
        {
            try
            {
                ItemsList = await ReservationService.FindByFilterAsync(Filter);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
