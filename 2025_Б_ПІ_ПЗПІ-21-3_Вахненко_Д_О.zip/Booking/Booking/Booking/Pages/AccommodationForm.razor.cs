﻿using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities;
using Microsoft.AspNetCore.Components;

namespace Booking.Pages
{
    public class AccommodationFormComponent : NotificationComponent
    {
        [Inject] public IAccommodationService AccommodationService { get; set; } = null!;
        [Parameter] public int? Id { get; set; }

        public Accommodation Model { get; set; } = new();

        public async Task OnSaveAsync()
        {
            try
            {
                Model = await AccommodationService.SaveAsync(Model);
                AddSuccess("Успішно збережено");
                NavigationManager.NavigateTo("/", true);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public void OnChangeFeature(Catalog catalog)
        {
            if (Model.Features.Any(f => f.CatalogId == catalog.Id))
            {
                Model.Features.Remove(Model.Features.First(f => f.CatalogId == catalog.Id));
            }
            else
            {
                Model.Features.Add(new Feature()
                {
                    CatalogId = catalog.Id
                });
            }
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                var currentUser = await GetCurrentUserAsync();
                Model.UserId = currentUser.Id;
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                if (Id.HasValue)
                {
                    Model = await AccommodationService.FindByIdAsync(Id.Value);
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
