﻿using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.Components.Enums;
using Booking.ViewServices;
using Microsoft.AspNetCore.Components;

namespace Booking.Pages.Administrator
{
    public class CatalogComponent : NotificationComponent
    {
        [Inject] private ICustomJSRuntime JsRuntime { get; set; } = null!;
        [Inject] private ICatalogueService CatalogueService { get; set; } = null!;

        public ModalType CurrentModal { get; protected set; } = ModalType.None;

        public bool Children { get; set; }

        public DAL.Entities.Catalog? SelectedCatalog { get; private set; }

        public string ModalTitle
        {
            get
            {
                if (SelectedCatalog != null)
                {
                    if (CurrentModal == ModalType.AddModal)
                    {
                        string title = "Створення каталогу";

                        if (!Children)
                        {
                            return title + $" {SelectedCatalog.Name}";
                        }

                        return title + $" {SelectedCatalog.Discriminator}";
                    }

                    if (CurrentModal == ModalType.EditModal)
                    {
                        return $"Редагування каталогу {SelectedCatalog.Discriminator}";
                    }

                    if (CurrentModal == ModalType.DeleteModal)
                    {
                        return $"Ви впевнені, що бажаєте видалити \"{SelectedCatalog.Name}\" ?";
                    }
                }

                return string.Empty;
            }
        }

        public CatalogComponent() : base("Каталоги") { }

        protected override void OnInitialized()
        {
            try
            {
                Title = "Каталоги";
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnDeleteAsync()
        {
            try
            {
                if (SelectedCatalog != null)
                {
                    await CatalogueService.DeleteAsync(SelectedCatalog.Id);
                    SelectedCatalog = null;
                    await CloseModalAsync();
                    AddSuccess("Каталог видалено.");
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public Task OpenModal(ModalType modalType, DAL.Entities.Catalog catalog, bool children = false)
        {
            CurrentModal = modalType;
            SelectedCatalog = catalog;
            Children = children;
            return Task.CompletedTask;
        }

        public async Task CloseModalAsync()
        {
            try
            {
                var currentModal = CurrentModal;
                CurrentModal = ModalType.None;
                await JsRuntime.CloseModalAsync(currentModal.ToString());
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
