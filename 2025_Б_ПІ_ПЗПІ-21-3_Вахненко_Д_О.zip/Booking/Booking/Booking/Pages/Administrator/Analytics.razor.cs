﻿using Booking.BLL.Models.Business;
using Booking.BLL.Models.Charts.Settings;
using Booking.BLL.Models.Filters;
using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities.Identity;
using Microsoft.AspNetCore.Components;
using System.Linq.Expressions;
using System.Reflection;

namespace Booking.Pages.Administrator
{
    public class AnalyticsComponent : NotificationComponent
    {
        private const string _chartId = "chart-reservations-by-users";
        [Inject] public IAnalyticsService AnalyticsService { get; set; } = null!;

        public AnalyticsInfo Info { get; set; } = new();

        public AnalyticsFilter Filter { get; set; } = new();

        public Task OnChangeUserGroup(int userGroupId)
        {
            if (Filter.UserGroups.Any(f => f == userGroupId))
            {
                Filter.UserGroups.Remove(Filter.UserGroups.First(f => f == userGroupId));
            }
            else
            {
                Filter.UserGroups.Add(userGroupId);
            }

            return LoadDataAsync();
        }

        public Task OnChangeStart(DateTime? value)
        {
            Filter.Start = value.Value;
            return LoadDataAsync();
        }

        public Task OnChangeEnd(DateTime? value)
        {
            Filter.End = value.Value;
            return LoadDataAsync();
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                await LoadDataAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected async Task LoadDataAsync()
        {
            Info = await AnalyticsService.FindInfoAsync(Filter);

            var settings = new LineChartSplineSettings()
            {
                Height = 190
            };

            var chartData = await AnalyticsService.FindChartReservationByUsersAsync(Filter);
            await JsRuntime.DrawLineChartSplineAsync(_chartId, chartData, settings);
        }
    }
}
