﻿using Booking.BLL.Services.Entities;
using Booking.Components;
using Booking.DAL.Entities;
using Booking.Infrastructure;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;

namespace Booking.Pages.Administrator
{
    public class CatalogFormComponent : NotificationComponent
    {
        [Inject] private ICatalogueService CatalogueService { get; set; } = null!;

        [Parameter] public EventCallback<DAL.Entities.Catalog> OnChanged { get; set; }
        [Parameter] public bool Children { get; set; }
        [Parameter] public DAL.Entities.Catalog? Parent { get; set; } = null!;
        [Parameter] public DAL.Entities.Catalog Catalogue { get; set; } = new();

        public bool Edit { get; private set; }

        public CatalogFormComponent()
            : base("Каталоги")
        {
        }

        public async Task SaveAsync(EditContext context)
        {
            try
            {
                if (Edit)
                {
                    await EditAsync();
                }
                else
                {
                    await AddAsync();
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected async Task AddAsync()
        {
            try
            {
                if (Parent != null)
                {
                    if (Children)
                    {
                        Catalogue.ParentId = Parent.Id;
                        if (Parent.Discriminator == nameof(Country))
                        {
                            Catalogue.Discriminator = nameof(Region);
                        }
                    }
                    else
                    {
                        Catalogue.Discriminator = Parent.Discriminator;
                    }
                }

                Catalogue = await CatalogueService.CreateAsync(Catalogue);
                await OnChanged.InvokeDelegateAsync(Catalogue);
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }

        protected async Task EditAsync()
        {
            try
            {
                Catalogue = await CatalogueService.UpdateAsync(Catalogue);
                await OnChanged.InvokeDelegateAsync(Catalogue);
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }

        protected override void OnParametersSet()
        {
            try
            {
                Edit = Catalogue.Id != 0;
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                Title = "Каталоги";
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
