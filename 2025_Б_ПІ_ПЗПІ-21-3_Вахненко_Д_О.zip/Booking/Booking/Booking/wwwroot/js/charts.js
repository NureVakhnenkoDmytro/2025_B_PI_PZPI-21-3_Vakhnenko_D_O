function getChartColorsArray(e) {
    if (null !== document.getElementById(e)) {
        e = document.getElementById(e).getAttribute("data-colors");
        if (e)
            return (e = JSON.parse(e)).map(function (e) {
                let t = e.replace(" ", "");
                if (-1 === t.indexOf(",")) {
                    let a = getComputedStyle(document.documentElement).getPropertyValue(t);
                    return a || t
                }
                e = e.split(",");
                return 2 != e.length ? t : "rgba(" + getComputedStyle(document.documentElement).getPropertyValue(e[0]) + "," + e[1] + ")"
            })
    }
}

function formatValue(value) {
    let values = String(value).split('.');
    let stringValue = '';

    if (values[0].length > 3) {
        let count = 0;
        for (let i = values[0].length - 1; i > -1; i--) {
            if (count != 0 && count % 3 == 0) {
                stringValue = ' ' + stringValue;
            }

            stringValue = values[0][i] + stringValue;
            count++;
        }
    }
    else {
        stringValue = values[0];
    }

    if (values[1] != undefined) {
        stringValue += '.' + values[1].substring(0, 2);
    }

    return stringValue;
}

var charts = new Object();

function drawRadialBarChart(id, percentageFill, settings) {
    let options, colors = getChartColorsArray(id);
    options = {
        chart: {
            type: "radialBar",
            fontFamily: 'inherit',
            height: settings.height,
            width: settings.width,
            animations: {
                enabled: false
            },
            sparkline: {
                enabled: true
            },
        },
        tooltip: {
            enabled: false,
        },
        plotOptions: {
            radialBar: {
                hollow: {
                    margin: 0,
                    size: '75%'
                },
                track: {
                    margin: 0
                },
                dataLabels: {
                    show: false
                }
            }
        },
        colors: colors,
        series: [percentageFill]
    };

    if (charts[id] != undefined) {
        charts[id].destroy();
    }

    charts[id] = new ApexCharts(document.querySelector("#" + id), options);
    charts[id].render();
}

function drawLineChartSpline(id, categories, series, settings) {
    let options, colors = getChartColorsArray(id);
    options = {
        chart: {
            type: "area",
            fontFamily: 'inherit',
            height: settings.height,
            sparkline: {
                enabled: true
            },
            animations: {
                enabled: false
            },
        },
        dataLabels: {
            enabled: false,
        },
        fill: {
            opacity: .16,
            type: 'solid'
        },
        stroke: {
            width: 2,
            lineCap: "round",
            curve: "smooth",
        },
        series: series,
        grid: {
            strokeDashArray: 4,
        },
        xaxis: {
            labels: {
                padding: 0,
            },
            tooltip: {
                enabled: false
            },
            axisBorder: {
                show: false,
            },
            type: 'datetime',
        },
        yaxis: {
            labels: {
                padding: 4
            },
        },
        labels: categories,
        colors: colors,
        legend: {
            show: false,
        },
        point: {
            show: false
        }
    };

    if (charts[id] != undefined) {
        charts[id].destroy();
    }

    charts[id] = new ApexCharts(document.querySelector("#" + id), options);
    charts[id].render();
}

function drawLineChartDashed(id, categories, series, settings) {
    let options, chartColors = getChartColorsArray(id);
    options = {
        chart: {
            height: settings.height,
            type: "line",
            zoom: {
                enabled: false
            },
            toolbar: {
                show: false
            }
        },
        colors: chartColors,
        dataLabels: {
            enabled: false
        },
        stroke: {
            width: [3, 4, 3],
            curve: "straight",
            dashArray: [0, 8, 5]
        },
        series: series,
        title: {
            text: settings.title,
            align: "left",
            style: {
                fontWeight: 500
            }
        },
        legend: {
            tooltipHoverFormatter: function (val, opts) {
                let value = opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex];

                if (settings.reduceByThouthand) {
                    return val + ' - ' + formatValue(value / 1000) + " K";
                }

                return val + ' - ' + formatValue(value);
            }
        },
        markers: {
            size: 0,
            hover: {
                sizeOffset: 6
            }
        },
        yaxis: {
            labels: {
                formatter: function (value) {

                    if (settings.reduceByThouthand) {
                        return formatValue(value / 1000) + " K";
                    }

                    return formatValue(value);
                }
            }
        },
        xaxis: {
            categories: categories
        },
        tooltip: {
            y: [{
                title: {
                    formatter: function (e, opts) {
                        return e + ' ' + settings.postfix;
                    }
                }
            }, {
                title: {
                    formatter: function (e, opts) {
                        return e + ' ' + settings.postfix;
                    }
                }
            }, {
                title: {
                    formatter: function (e, opts) {
                        return e + ' ' + settings.postfix;
                    }
                }
            }]
        },
        grid: {
            borderColor: "#f1f1f1"
        }
    };

    if (charts[id] != undefined) {
        charts[id].destroy();
    }

    charts[id] = new ApexCharts(document.querySelector("#" + id), options);
    charts[id].render();
}

function drawChartGroupedBar(id, categories, series, settings) {
    let options, chartColors = getChartColorsArray(id);
    options = {
        series: series,
        chart: {
            type: "bar",
            height: settings.height,
            toolbar: {
                show: false
            }
        },
        plotOptions: {
            bar: {
                horizontal: true,
                dataLabels: {
                    position: "top"
                }
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: true,
            width: 1,
            colors: ["#fff"]
        },
        tooltip: {
            shared: true,
            intersect: false,
            y: [{
                formatter: function (value) {
                    return formatValue(value / 1000) + " K";
                }
            }, {
                formatter: function (value) {
                    return formatValue(value / 1000) + " K";
                }
            }, {
                formatter: function (value) {
                    return formatValue(value / 1000) + " K";
                }
            }]
        },
        legend: {
            tooltipHoverFormatter: function (val, opts) {
                let value = opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex];
                return val + ' - ' + formatValue(value / 1000) + " K";
            }
        },
        xaxis: {
            categories: categories,
            labels: {
                formatter: function (value) {
                    return formatValue(value / 1000) + " K";
                }
            }
        },
        yaxis: {
            show: true,
            labels: {
                show: true,
                align: 'right',
                maxWidth: settings.yaxisLabelsMaxWidth
            }
        },
        colors: chartColors
    };

    if (charts[id] != undefined) {
        charts[id].destroy();
    }

    charts[id] = new ApexCharts(document.querySelector("#" + id), options);
    charts[id].render();
}

function drawChartStackedBar100(id, categories, series, settings) {
    let options, chartColors = getChartColorsArray(id);
    options = {
        series: series,
        chart: {
            type: "bar",
            height: settings.height,
            stacked: true,
            stackType: "100%",
            toolbar: {
                show: false
            }
        },
        plotOptions: {
            bar: {
                horizontal: true
            }
        },
        stroke: {
            width: 1,
            colors: ["#fff"]
        },
        title: {
            text: settings.title,
            style: {
                fontWeight: 500
            }
        },
        xaxis: {
            categories: categories
        },
        yaxis: {
            show: true,
            labels: {
                show: true,
                align: 'right',
                maxWidth: settings.yaxisLabelsMaxWidth
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    if (settings.direction == "Pay") {
                        return formatValue(value / 1000) + " K";
                    } else if (settings.direction == "Delivery") {
                        return formatValue(value);
                    }

                    return value;
                },
            },
        },
        fill: {
            opacity: 1
        },
        legend: {
            position: "top",
            horizontalAlign: "left",
            offsetX: 40
        },
        colors: chartColors
    }

    if (charts[id] != undefined) {
        charts[id].destroy();
    }

    charts[id] = new ApexCharts(document.querySelector("#" + id), options);
    charts[id].render();
}