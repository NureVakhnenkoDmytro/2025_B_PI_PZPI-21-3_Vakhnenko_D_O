﻿using Microsoft.AspNetCore.Components;
using System.ComponentModel;

namespace Booking.ViewServices
{
    public interface ITitleService : INotifyPropertyChanged
    {
        string Title { get; set; }

        MarkupString TitleHTML { get; }

        bool ContainsHTML { get; }
    }
}
