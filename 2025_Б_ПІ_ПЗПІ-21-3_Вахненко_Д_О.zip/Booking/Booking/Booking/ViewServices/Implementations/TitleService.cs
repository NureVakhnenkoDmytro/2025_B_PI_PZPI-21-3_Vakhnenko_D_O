using Microsoft.AspNetCore.Components;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Web;

namespace Booking.ViewServices.Implementations
{
    public class TitleService : ITitleService
    {
        private string _title = string.Empty;
        public event PropertyChangedEventHandler? PropertyChanged;

        public string Title
        {
            get => _title;
            set
            {
                _title = value;
                OnPropertyChanged();
            }
        }

        public MarkupString TitleHTML => (MarkupString) Title;

        public bool ContainsHTML => Title != HttpUtility.HtmlEncode(Title);

        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
