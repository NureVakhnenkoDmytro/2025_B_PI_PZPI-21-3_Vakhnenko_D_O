﻿namespace Booking.ViewServices.Implementations
{
    public class ErrorTranslator : IErrorTranslator
    {
        private readonly Dictionary<string, string> _translations;

        public ErrorTranslator()
        {
            _translations = new Dictionary<string, string>();
            _translations.Add("The DELETE statement conflicted with the SAME TABLE REFERENCE constraint \"FK_Contracts_Contracts_ParentId\". The conflict occurred in database \"Reporting\", table \"dbo.Contracts\", column 'ParentId'.\r\nThe statement has been terminated.", "Спочатку потрібно видалити всі додаткові угоди цього контракту.");
            _translations.Add("The DELETE statement conflicted with the REFERENCE constraint \"FK_Specifications_Contracts_ContractId\". The conflict occurred in database \"Reporting\", table \"dbo.Specifications\", column 'ContractId'.\r\nThe statement has been terminated.", "Спочатку потрібно видалити всі специфікації цього контракту.");
            _translations.Add("The DELETE statement conflicted with the REFERENCE constraint \"FK_Deviations_Contracts_ContractId\". The conflict occurred in database \"Reporting\", table \"dbo.Deviations\", column 'ContractId'.\r\nThe statement has been terminated.", "Спочатку потрібно видалити всі відхилення цього контракту.");
        }

        public string this[Exception ex]
        {
            get
            {
                if (ex.Message == "An error occurred while saving the entity changes. See the inner exception for details.")
                {
                    return this[ex!.InnerException!.Message];
                }

                return this[ex.Message];
            }
        }

        public string this[string message]
        {
            get
            {
                if (_translations.ContainsKey(message))
                {
                    return _translations[message];
                }

                return message;
            }
        }
    }
}
