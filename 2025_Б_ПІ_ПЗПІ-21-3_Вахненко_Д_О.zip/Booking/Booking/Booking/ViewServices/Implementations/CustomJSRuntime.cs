﻿using Booking.BLL.Models.Charts;
using Booking.BLL.Models.Charts.Common;
using Booking.BLL.Models.Charts.Settings;
using Microsoft.JSInterop;

namespace Booking.ViewServices.Implementations
{
    public class CustomJSRuntime : ICustomJSRuntime
    {
        private readonly IJSRuntime _jsRuntime;

        public CustomJSRuntime(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public async Task OpenModalAsync(string modalId)
        {
            await _jsRuntime.InvokeVoidAsync("OpenModal", modalId);
        }

        public async Task CloseModalAsync(string modalId)
        {
            await _jsRuntime.InvokeVoidAsync("CloseModal", modalId);
        }

        public async Task DownloadFileFromStreamAsync(string fileName, Stream fileStream)
        {
            using var streamRef = new DotNetStreamReference(fileStream);
            await _jsRuntime.InvokeVoidAsync("downloadFileFromStream", fileName, streamRef);
        }

        public async Task DrawLineChartSplineAsync(string id, ChartData<LineChartSplineData> chartData, LineChartSplineSettings? settings = null)
        {
            settings ??= new LineChartSplineSettings();
            await _jsRuntime.InvokeVoidAsync("drawLineChartSpline", id, chartData.Categories, chartData.Series, settings);
        }

        public async Task DrawRadialBarChartsAsync(string id, double percentageFill, RadialBarChartSettings? settings = null)
        {
            settings ??= new RadialBarChartSettings();
            await _jsRuntime.InvokeVoidAsync("drawRadialBarChart", id, percentageFill, settings);
        }

        public async Task DrawLineChartDashedAsync(string id, ChartData<LineChartDashedData> chartData, LineChartDashedSettings settings)
        {
            await _jsRuntime.InvokeVoidAsync("drawLineChartDashed", id, chartData.Categories, chartData.Series, settings);
        }

        public async Task DrawChartGroupedBarAsync(string id, ChartData<ChartGroupedBarData> chartData, GroupedBarChartSettings? settings = null)
        {
            settings ??= new GroupedBarChartSettings();
            settings.Height = CalculateHeight(chartData, settings.Height);
            await _jsRuntime.InvokeVoidAsync("drawChartGroupedBar", id, chartData.Categories, chartData.Series, settings);
        }

        public async Task DrawChartStackedBar100Async(string id, ChartData<StackedBars100Data> chartData, StackedBars100Settings? settings = null)
        {
            settings ??= new StackedBars100Settings();
            settings.Height = CalculateHeight(chartData, settings.Height);
            await _jsRuntime.InvokeVoidAsync("drawChartStackedBar100", id, chartData.Categories, chartData.Series, settings);
        }

        private double CalculateHeight<T>(ChartData<T> chartData, double height)
        {
            const double rowHeight = 15;
            const double minHeight = 600;

            if (height == 0)
            {
                height = rowHeight * chartData.Categories.Count;

                if (height < minHeight && chartData.Categories.Count > 0)
                {
                    height = minHeight;
                }
            }

            return height;
        }
    }
}
