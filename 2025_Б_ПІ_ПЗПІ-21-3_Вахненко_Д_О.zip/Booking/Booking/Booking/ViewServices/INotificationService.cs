﻿using Booking.Models.Notifications;

namespace Booking.ViewServices
{
    public interface INotificationService
    {
        event EventHandler? NotificationsChanged;
        event EventHandler? NotificationTimerElapsed;

        bool HasNotification { get; }

        List<Notification> GetNotifications();

        void AddNotification(Notification notification);

        void ClearNotification(Notification notification);
    }
}
