﻿using Booking.BLL.Models.Charts;
using Booking.BLL.Models.Charts.Common;
using Booking.BLL.Models.Charts.Settings;

namespace Booking.ViewServices
{
    public interface ICustomJSRuntime
    {
        Task OpenModalAsync(string modalId);

        Task CloseModalAsync(string modalId);

        Task DownloadFileFromStreamAsync(string fileName, Stream fileStream);

        Task DrawLineChartSplineAsync(string id, ChartData<LineChartSplineData> chartData, LineChartSplineSettings? settings = null);

        Task DrawRadialBarChartsAsync(string id, double percentageFill, RadialBarChartSettings? settings = null);

        Task DrawLineChartDashedAsync(string id, ChartData<LineChartDashedData> chartData, LineChartDashedSettings settings);

        Task DrawChartGroupedBarAsync(string id, ChartData<ChartGroupedBarData> chartData, GroupedBarChartSettings? settings = null);

        Task DrawChartStackedBar100Async(string id, ChartData<StackedBars100Data> chartData, StackedBars100Settings? settings = null);
    }
}
