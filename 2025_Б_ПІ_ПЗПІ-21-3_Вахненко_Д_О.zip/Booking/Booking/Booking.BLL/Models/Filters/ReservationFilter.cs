﻿using Booking.BLL.Filters.Common;
using Booking.DAL.Entities;

namespace Booking.BLL.Models.Filters
{
    public class ReservationFilter : ExpressionFilter<Reservation>
    {
        public int? UserId { get; set; }

        public override QueryExpressions<Reservation> QueryExpressions
        {
            get
            {
                var expressions = base.QueryExpressions;

                if (UserId.HasValue)
                {
                    expressions.Add(r => r.UserId == UserId.Value);
                }

                return expressions;
            }
        }
    }
}
