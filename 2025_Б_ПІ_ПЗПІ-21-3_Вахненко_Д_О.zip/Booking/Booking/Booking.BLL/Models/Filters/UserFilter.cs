﻿using Booking.BLL.Filters.Common;
using Booking.DAL.Entities.Identity;

namespace Booking.BLL.Models.Filters
{
    public class UserFilter : ExpressionFilter<User>
    {
        public string? SearchPhrase { get; set; }

        public DateTime? RegisterDate { get; set; }

        public int? WithoutUserId { get; set; }

        public override QueryExpressions<User> QueryExpressions
        {
            get
            {
                var expressions = base.QueryExpressions;

                if (!string.IsNullOrEmpty(SearchPhrase))
                {
                    string phrase = SearchPhrase.ToLower();
                    expressions.Add(u => u.Email.ToLower().Contains(phrase));
                        //|| u.UserRoles.FirstOrDefault(ur => ur.Role.Name == Role.SuperAdmin) != null && u.Member.FullName.ToLower().Contains(phrase)
                        //|| u.UserRoles.FirstOrDefault(ur => ur.Role.Name == Role.Controller) != null && u.Member.BodyName.ToLower().Contains(phrase)
                        //|| (u.UserRoles.FirstOrDefault(ur => ur.Role.Name == Role.Member) != null
                        //    || u.UserRoles.FirstOrDefault(ur => ur.Role.Name == Role.Registered) != null)
                        //        && (u.Member.Clients.FirstOrDefault(c => c.IsMember) != null
                        //            && (u.Member.Clients.First(c => c.IsMember).ShortName.ToLower().Contains(phrase) || u.Member.Clients.First(c => c.IsMember).Code.ToLower().Contains(phrase)))
                        //|| u.UserRoles.First(ur => ur.Role.Name.ToLower().Contains(phrase)) != null);
                }

                if (WithoutUserId.HasValue)
                {
                    expressions.Add(u => u.Id != WithoutUserId.Value);
                }

                return expressions;
            }
        }
    }
}
