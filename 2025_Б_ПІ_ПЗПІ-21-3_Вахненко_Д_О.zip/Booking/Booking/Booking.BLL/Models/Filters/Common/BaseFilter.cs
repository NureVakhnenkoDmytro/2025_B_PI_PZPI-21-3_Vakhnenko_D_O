﻿namespace Booking.BLL.Models.Filters.Common
{
    public abstract class BaseFilter
    {
        private const int _pageNumberDefault = 1, _pageSizeDefault = 10;
        private const string _orderColumnDefault = "Id";
        private const OrderType _orderTypeDefault = OrderType.Ascending;

        private int _pageNumber, _pageSize;
        private string _orderColumn;
        private OrderType _orderType;

        public static OrderType DefaultOrderType => _orderTypeDefault;
        public static string DefaultOrderColumn => _orderColumnDefault;

        public int PageNumber
        {
            get
            {
                if (_pageNumber < 1)
                {
                    return _pageNumberDefault;
                }

                return _pageNumber;
            }
            set
            {
                _pageNumber = value;
            }
        }

        public int PageSize
        {
            get
            {
                if (_pageSize < 1)
                {
                    return _pageSizeDefault;
                }

                return _pageSize;
            }
            set
            {
                _pageSize = value;
            }
        }

        public string OrderColumn
        {
            get
            {
                if (string.IsNullOrEmpty(_orderColumn))
                {
                    return _orderColumnDefault;
                }

                return _orderColumn;
            }
            set
            {
                _orderColumn = value;
            }
        }

        public OrderType OrderType
        {
            get
            {
                return _orderType;
            }
            set
            {
                _orderType = value;
            }
        }

        public int SkipItemsCount => (PageNumber - 1) * PageSize;

        public BaseFilter()
        {
            _orderColumn = _orderColumnDefault;
            _orderType = _orderTypeDefault;
        }

        public TFilter Copy<TFilter>() where TFilter : BaseFilter
        {
            return (TFilter)this.MemberwiseClone();
        }
    }
}
