using System.Linq.Expressions;

namespace Booking.BLL.Filters.Common
{
    public class QueryExpressions<T> where T : class
    {
        private readonly List<Expression<Func<T, bool>>> _expressions;

        public QueryExpressions()
        {
            _expressions = new List<Expression<Func<T, bool>>>();
        }

        public void Add(Expression<Func<T, bool>> expression)
        {
            _expressions.Add(expression);
        }

        public Expression<Func<T, bool>>[] ToArray()
        {
            return _expressions.ToArray();
        }
    }
}
