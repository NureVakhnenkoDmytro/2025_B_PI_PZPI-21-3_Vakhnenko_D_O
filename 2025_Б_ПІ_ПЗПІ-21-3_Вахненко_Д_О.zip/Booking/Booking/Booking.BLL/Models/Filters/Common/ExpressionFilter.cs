﻿using Booking.BLL.Models.Filters.Common;
using System.Linq.Expressions;
using System.Reflection;

namespace Booking.BLL.Filters.Common
{
    public abstract class ExpressionFilter<TEntity> : BaseFilter where TEntity : class
    {
        public virtual QueryExpressions<TEntity> QueryExpressions => new QueryExpressions<TEntity>();

        public virtual Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? ToOrderBy()
        {
            try
            {
                if (!string.IsNullOrEmpty(OrderColumn))
                {
                    Type typeQueryable = typeof(IQueryable<TEntity>);
                    ParameterExpression argQueryable = Expression.Parameter(typeQueryable, "p");
                    var outerExpression = Expression.Lambda(argQueryable, argQueryable);
                    string[] props = OrderColumn.Split('.');
                    IQueryable<TEntity> query = new List<TEntity>().AsQueryable();
                    Type type = typeof(TEntity);
                    ParameterExpression arg = Expression.Parameter(type, "x");

                    Expression expr = arg;
                    foreach (string prop in props)
                    {
                        PropertyInfo? pi = type.GetProperty(prop, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);
                        
                        if (pi != null)
                        {
                            expr = Expression.Property(expr, pi);
                            type = pi.PropertyType;
                        }
                    }

                    LambdaExpression lambda = Expression.Lambda(expr, arg);
                    string methodName = OrderType == OrderType.Ascending ? "OrderBy" : "OrderByDescending";

                    MethodCallExpression resultExp =
                        Expression.Call(typeof(Queryable), methodName, new Type[] { typeof(TEntity), type }, outerExpression.Body, Expression.Quote(lambda));
                    var finalLambda = Expression.Lambda(resultExp, argQueryable);
                    return (Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>)finalLambda.Compile();
                }
            }
            catch (Exception)
            {
            }

            return null;
        }

        protected Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> SelectOrderType<T>(Expression<Func<TEntity, T>> expression)
        {
            if (OrderType == OrderType.Ascending)
            {
                return c => c.OrderBy(expression);
            }

            return c => c.OrderByDescending(expression);
        }
    }
}
