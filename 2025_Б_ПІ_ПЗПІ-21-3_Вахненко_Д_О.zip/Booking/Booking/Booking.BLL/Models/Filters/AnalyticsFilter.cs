﻿using AutoMapper.Features;
using Booking.BLL.Filters.Common;
using Booking.BLL.Models.Filters.Common;
using Booking.DAL.Entities;

namespace Booking.BLL.Models.Filters
{
    public class AnalyticsFilter : BaseFilter
    {
        public DateTime Start { get; set; } = DateTime.Now.AddDays(-7);

        public DateTime End { get; set; } = DateTime.Now.AddDays(7);

        public List<int> UserGroups { get; set; } = new();

        public QueryExpressions<Accommodation> AccommodationExpressions
        {
            get
            {
                var expressions = new QueryExpressions<Accommodation>();

                expressions.Add(a => Start.Date <= a.LeaseStart.Date);
                expressions.Add(a => a.LeaseEnd.Date <= End.Date);

                if (UserGroups.Any())
                {
                    expressions.Add(a => a.Features.Count(f => UserGroups.Contains(f.CatalogId)) == UserGroups.Count);
                }

                return expressions;
            }
        }

        public QueryExpressions<Reservation> ReservationExpressions
        {
            get
            {
                var expressions = new QueryExpressions<Reservation>();

                expressions.Add(r => Start.Date <= r.Start);
                expressions.Add(r => r.End.Date <= End.Date);

                if (UserGroups.Any())
                {
                    expressions.Add(r => r.Accommodation.Features.Count(f => UserGroups.Contains(f.CatalogId)) == UserGroups.Count);
                }

                return expressions;
            }
        }
    }
}
