﻿using Booking.BLL.Filters.Common;
using Booking.DAL.Entities;
using Booking.DAL.Entities.Enums;

namespace Booking.BLL.Models.Filters
{
    public class AccommodationFilter : ExpressionFilter<Accommodation>
    {
        public string? Search { get; set; }

        public decimal? PricePerHourMin { get; set; }

        public decimal? PricePerHourMax { get; set; }

        public DateTime? LeaseStart { get; set; }

        public DateTime? LeaseEnd { get; set; }

        public List<int> Features { get; set; } = new();

        public List<int> UserGroups { get; set; } = new();

        public override QueryExpressions<Accommodation> QueryExpressions
        {
            get
            {
                var expressions = base.QueryExpressions;

                if (!string.IsNullOrEmpty(Search))
                {
                    expressions.Add(a => a.Name.ToLower().Contains(Search.ToLower()) 
                        || a.Description.ToLower().Contains(Search.ToLower()));
                }

                if (PricePerHourMin.HasValue)
                {
                    expressions.Add(a => a.PricePerHour >= PricePerHourMin.Value);
                }

                if (PricePerHourMax.HasValue)
                {
                    expressions.Add(a => a.PricePerHour <= PricePerHourMax.Value);
                }

                if (LeaseStart.HasValue)
                {
                    expressions.Add(a => a.LeaseStart.Date <= LeaseStart.Value.Date
                        && (!a.Reservations.Any(r => r.Type != ReservationType.Canceled)));
                }

                if (LeaseEnd.HasValue)
                {
                    expressions.Add(a => a.LeaseEnd.Date >= LeaseEnd.Value.Date
                            && (!a.Reservations.Any(r => r.Type != ReservationType.Canceled)));
                }

                if (Features.Any() || UserGroups.Any())
                {
                    var features = new List<int>();
                    features.AddRange(Features);
                    features.AddRange(UserGroups);
                    expressions.Add(a => a.Features.Count(f => features.Contains(f.CatalogId)) == features.Count);
                }

                return expressions;
            }
        }

    }
}
