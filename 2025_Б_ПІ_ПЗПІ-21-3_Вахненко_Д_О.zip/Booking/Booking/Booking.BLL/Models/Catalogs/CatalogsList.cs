﻿using Booking.DAL.Entities;
using System.Collections;

namespace Booking.BLL.Models.Catalogs
{
    public class CatalogsList<TCatalog> : IEnumerable<TCatalog> where TCatalog : Catalog
    {
        protected readonly List<TCatalog> _catalogs;

        public TCatalog this[int id] => _catalogs.First(c => c.Id == id);

        public CatalogsList(List<Catalog> catalogs)
        {
            if (typeof(Catalog) != typeof(TCatalog))
            {
                catalogs = catalogs.Where(c => c.Discriminator == typeof(TCatalog).Name).ToList();
            }

            _catalogs = catalogs.OrderBy(g => g.Name).Cast<TCatalog>().ToList();

            //add children
        }

        public CatalogsList(List<TCatalog> catalogs)
        {
            _catalogs = catalogs.ToList();
        }

        public List<TCatalog> FindByParent(int? parentId)
        {
            return _catalogs
                //.Where(c => c.Discriminator == typeof(Parent).Name)
                //.Cast<Parent>()
                //.Where(c => c.ParentId == parentId)
                .ToList();
        }

        public IEnumerator<TCatalog> GetEnumerator()
        {
            return _catalogs.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
