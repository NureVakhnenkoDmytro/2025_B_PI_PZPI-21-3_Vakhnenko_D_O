﻿namespace Booking.BLL.Models.Business
{
    public class AnalyticsInfo
    {
        public int AccommodationCount { get; set; }

        public int ReservationCount { get; set; }

        public decimal ReservationsCost { get; set; }

        public decimal ReservationsHours { get; set; }
    }
}
