﻿namespace Booking.BLL.Models.Charts
{
    public class LineChartDashedData
    {
        public string Name { get; set; } = null!;

        public List<decimal> Data { get; set; } = null!;

        public LineChartDashedData()
        {
            Name = string.Empty;
            Data = new List<decimal>();
        }
    }
}
