﻿namespace Booking.BLL.Models.Charts
{
    public class StackedBars100Data
    {
        public string Name { get; set; } = null!;

        public List<decimal> Data { get; set; } = null!;

        public StackedBars100Data()
        {
            Name = string.Empty;
            Data = new List<decimal>();
        }

        public StackedBars100Data(string name)
            : this()
        {
            Name = name;
        }
    }
}
