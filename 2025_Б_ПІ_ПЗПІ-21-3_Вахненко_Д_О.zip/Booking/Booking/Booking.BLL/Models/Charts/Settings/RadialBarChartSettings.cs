﻿namespace Booking.BLL.Models.Charts.Settings
{
    public class RadialBarChartSettings
    {
        public double Height { get; set; } = 40;

        public double Width { get; set; } = 40;
    }
}
