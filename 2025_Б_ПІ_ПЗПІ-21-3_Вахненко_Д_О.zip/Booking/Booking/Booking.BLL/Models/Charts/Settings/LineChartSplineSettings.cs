﻿namespace Booking.BLL.Models.Charts.Settings
{
    public class LineChartSplineSettings
    {
        public double Height { get; set; } = 192;
    }
}
