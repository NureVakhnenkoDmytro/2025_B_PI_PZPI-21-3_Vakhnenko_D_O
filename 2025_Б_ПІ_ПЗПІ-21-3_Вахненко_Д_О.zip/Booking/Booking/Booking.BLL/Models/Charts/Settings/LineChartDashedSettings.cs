﻿namespace Booking.BLL.Models.Charts.Settings
{
    public class LineChartDashedSettings
    {
        public string Title = string.Empty;

        public string? Postfix { get; set; }

        public bool ReduceByThouthand { get; set; } = true;

        public double Height { get; set; } = 380;
    }
}
