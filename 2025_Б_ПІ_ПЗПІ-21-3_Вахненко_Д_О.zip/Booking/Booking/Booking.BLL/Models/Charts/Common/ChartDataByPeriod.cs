﻿namespace Booking.BLL.Models.Charts.Common
{
    public class ChartDataByPeriod<TChartData>
    {
        public ChartData<TChartData> Current { get; private set; }

        public ChartData<TChartData> Previous { get; private set; }

        public ChartDataByPeriod()
        {
            Current = new ChartData<TChartData>();
            Previous = new ChartData<TChartData>();
        }
    }
}
