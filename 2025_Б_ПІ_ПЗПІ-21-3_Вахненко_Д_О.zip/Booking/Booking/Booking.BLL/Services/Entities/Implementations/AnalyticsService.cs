﻿using Booking.BLL.Models.Business;
using Booking.BLL.Models.Charts;
using Booking.BLL.Models.Charts.Common;
using Booking.BLL.Models.Filters;
using Booking.DAL.UnitOfWork;

namespace Booking.BLL.Services.Entities.Implementations
{
    public class AnalyticsService : IAnalyticsService
    {
        private readonly IUnitOfWork _unitOfWork;

        public AnalyticsService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<AnalyticsInfo> FindInfoAsync(AnalyticsFilter filter)
        {
            var info = new AnalyticsInfo();

            var accommodations = await _unitOfWork.Accommodations.GetAllAsync(filter.AccommodationExpressions.ToArray(), null);
            var reservations = await _unitOfWork.Reservations.GetAllAsync(filter.ReservationExpressions.ToArray(), null);

            info.AccommodationCount = accommodations.Count();
            info.ReservationCount = reservations.Count();
            info.ReservationsCost = reservations.Sum(r => r.Cost);
            info.ReservationsHours = reservations.Sum(r => (decimal)(r.End - r.Start).TotalHours);

            return info;
        }

        public async Task<ChartData<LineChartSplineData>> FindChartReservationByUsersAsync(AnalyticsFilter filter)
        {
            try
            {
                var reservations = await _unitOfWork.Reservations.GetAllAsync(filter.ReservationExpressions.ToArray(), null);
                var chartData = new ChartData<LineChartSplineData>();

                var dates = new List<DateTime>();
                var start = filter.Start.Date;

                while (start.Date <= filter.End.Date)
                {
                    dates.Add(start);
                    start = start.AddDays(1);
                }

                chartData.Categories.AddRange(dates.Select(d => d.ToString("yyyy-MM-dd")));

                foreach (var reservationsByUser in reservations.GroupBy(r => r.User))
                {
                    var lineChartSplineData = new LineChartSplineData();
                    lineChartSplineData.Name = reservationsByUser.Key!.UserName;

                    var reservationsByDate = reservationsByUser.GroupBy(r => r.Date.Date);

                    foreach (var date in dates)
                    {
                        var reservationCostByDay = reservationsByDate.Where(r => r.Key == date).Sum(r => r.Sum(d => d.CostByDay));
                        lineChartSplineData.Data.Add(reservationCostByDay);
                    }

                    chartData.Series.Add(lineChartSplineData);
                }

                return chartData;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
