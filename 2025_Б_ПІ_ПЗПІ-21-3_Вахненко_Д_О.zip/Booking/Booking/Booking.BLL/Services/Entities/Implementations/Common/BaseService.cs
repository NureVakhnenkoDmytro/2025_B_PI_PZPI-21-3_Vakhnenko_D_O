﻿using Booking.BLL.Filters.Common;
using Booking.BLL.Models.Business.Common;
using Booking.DAL.Repositories;
using Booking.DAL.UnitOfWork;

namespace Booking.BLL.Services.Entities.Implementations.Common
{
    public abstract class BaseService<TEntity, TRepository>
        where TEntity : class
        where TRepository : IRepository<TEntity>
    {
        protected readonly IUnitOfWork _unitOfWork;
        protected readonly TRepository _repository;

        public BaseService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
            _repository = unitOfWork.GetTRepository<TRepository>();
        }

        public virtual async Task<List<TEntity>> FindAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public virtual async Task<TEntity> FindByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public virtual async Task<TEntity?> FindFirstOrDefaultAsync()
        {
            return await _repository.GetFirstOrDefaultAsync();
        }

        public virtual async Task<TEntity> SaveAsync(TEntity entity)
        {
            var id = ((int?)entity.GetType()?.GetProperty("Id")?.GetValue(entity) ?? 0);

            if (id == 0)
            {
                return await _repository.InsertAsync(entity);
            }

            return await _repository.UpdateAsync(entity);
        }

        public virtual async Task<TEntity> CreateAsync(TEntity entity)
        {
            return await _repository.InsertAsync(entity);
        }

        public virtual async Task<TEntity> UpdateAsync(TEntity entity)
        {
            return await _repository.UpdateAsync(entity);
        }

        public virtual async Task<TEntity> DeleteAsync(int entityId)
        {
            return await _repository.DeleteAsync(entityId);
        }

        protected virtual async Task<ItemsList<TEntity>> FindByFilterAsync<TFilter>(TFilter filter, params string[] includeProperties)
            where TFilter : ExpressionFilter<TEntity>
        {
            ItemsList<TEntity> itemsList = new(filter);
            var expressions = filter.QueryExpressions.ToArray();
            itemsList.TotalItems = await _repository.GetCountAsync(expressions);
            var orderBy = filter.ToOrderBy();

            if (includeProperties.Length > 0)
            {
                itemsList.Items = await _repository.GetAllAsync(filter.SkipItemsCount, filter.PageSize, orderBy, includeProperties, expressions);
            }
            else
            {
                itemsList.Items = await _repository.GetAllAsync(filter.SkipItemsCount, filter.PageSize, orderBy, expressions);
            }

            return itemsList;
        }
    }
}
