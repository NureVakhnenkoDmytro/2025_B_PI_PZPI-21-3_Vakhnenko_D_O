﻿using Booking.BLL.Services.Entities.Implementations.Common;
using Booking.DAL.Entities;
using Booking.DAL.Repositories;
using Booking.DAL.UnitOfWork;

namespace Booking.BLL.Services.Entities.Implementations
{
    class CatalogueService : BaseService<Catalog, IRepository<Catalog>>, ICatalogueService
    {
        public CatalogueService(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        public override async Task<Catalog> CreateAsync(Catalog entity)
        {
            var created = await base.CreateAsync(entity);
            await ST.ReloadCatalogsAsync(_unitOfWork);
            return created;
        }

        public override async Task<Catalog> UpdateAsync(Catalog entity)
        {
            var updated = await base.UpdateAsync(entity);
            await ST.ReloadCatalogsAsync(_unitOfWork);
            return updated;
        }

        public override async Task<Catalog> DeleteAsync(int id)
        {
            var deleted = await base.DeleteAsync(id);
            await ST.ReloadCatalogsAsync(_unitOfWork);
            return deleted;
        }
    }
}
