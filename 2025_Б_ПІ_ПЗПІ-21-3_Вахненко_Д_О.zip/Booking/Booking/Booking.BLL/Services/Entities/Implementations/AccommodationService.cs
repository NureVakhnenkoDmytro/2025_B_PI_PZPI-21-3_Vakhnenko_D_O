﻿using Booking.BLL.Models.Business.Common;
using Booking.BLL.Models.Filters;
using Booking.BLL.Services.Entities.Implementations.Common;
using Booking.DAL.Entities;
using Booking.DAL.Repositories;
using Booking.DAL.UnitOfWork;

namespace Booking.BLL.Services.Entities.Implementations
{
    public class AccommodationService : BaseService<Accommodation, IRepository<Accommodation>>, IAccommodationService
    {
        public AccommodationService(IUnitOfWork unitOfWork) 
            : base(unitOfWork)
        {
        }

        public async Task<ItemsList<Accommodation>> FindByFilterAsync(AccommodationFilter filter)
        {
            return await base.FindByFilterAsync(filter);
        }
    }
}
