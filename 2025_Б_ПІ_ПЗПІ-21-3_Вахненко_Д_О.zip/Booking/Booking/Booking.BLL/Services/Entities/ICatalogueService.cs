﻿using Booking.DAL.Entities;

namespace Booking.BLL.Services.Entities
{
    public interface ICatalogueService
    {
        Task<List<Catalog>> FindAllAsync();

        Task<Catalog> CreateAsync(Catalog entity);

        Task<Catalog> UpdateAsync(Catalog entity);

        Task<Catalog> DeleteAsync(int entityId);
    }
}
