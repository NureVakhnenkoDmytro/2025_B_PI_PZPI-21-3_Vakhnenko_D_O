﻿using Booking.BLL.Models.Business.Common;
using Booking.BLL.Models.Filters;
using Booking.DAL.Entities;

namespace Booking.BLL.Services.Entities
{
    public interface IAccommodationService
    {
        Task<List<Accommodation>> FindAllAsync();

        Task<Accommodation> FindByIdAsync(int id);

        Task<Accommodation?> FindFirstOrDefaultAsync();

        Task<Accommodation> SaveAsync(Accommodation entity);

        Task<Accommodation> CreateAsync(Accommodation entity);

        Task<Accommodation> UpdateAsync(Accommodation entity);

        Task<Accommodation> DeleteAsync(int entityId);

        Task<ItemsList<Accommodation>> FindByFilterAsync(AccommodationFilter filter);
    }
}
