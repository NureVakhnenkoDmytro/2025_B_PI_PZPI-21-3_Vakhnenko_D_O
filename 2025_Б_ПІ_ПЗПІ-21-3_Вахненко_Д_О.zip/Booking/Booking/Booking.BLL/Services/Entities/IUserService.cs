﻿using Booking.BLL.Models.Business.Common;
using Booking.BLL.Models.Filters;
using Booking.DAL.Entities.Identity;

namespace Booking.BLL.Services.Entities
{
    public interface IUserService
    {
        Task<ItemsList<User>> FindByFilterAsync(UserFilter filter);

        Task<User> CreateAsync(User user);

        Task<User> UpdateAsync(User user);
    }
}
