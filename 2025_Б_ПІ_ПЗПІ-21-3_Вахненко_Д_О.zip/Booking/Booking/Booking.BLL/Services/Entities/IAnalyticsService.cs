﻿using Booking.BLL.Models.Business;
using Booking.BLL.Models.Charts.Common;
using Booking.BLL.Models.Charts;
using Booking.BLL.Models.Filters;

namespace Booking.BLL.Services.Entities
{
    public interface IAnalyticsService
    {
        Task<AnalyticsInfo> FindInfoAsync(AnalyticsFilter filter);

        Task<ChartData<LineChartSplineData>> FindChartReservationByUsersAsync(AnalyticsFilter filter);
    }
}
