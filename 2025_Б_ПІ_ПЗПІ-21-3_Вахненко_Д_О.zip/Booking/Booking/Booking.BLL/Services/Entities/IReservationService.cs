﻿using Booking.BLL.Models.Business.Common;
using Booking.BLL.Models.Filters;
using Booking.DAL.Entities;

namespace Booking.BLL.Services.Entities
{
    public interface IReservationService
    {
        Task<List<Reservation>> FindAllAsync();

        Task<Reservation> FindByIdAsync(int id);

        Task<Reservation?> FindFirstOrDefaultAsync();

        Task<Reservation> SaveAsync(Reservation entity);

        Task<Reservation> CreateAsync(Reservation entity);

        Task<Reservation> UpdateAsync(Reservation entity);

        Task<Reservation> DeleteAsync(int entityId);

        Task<ItemsList<Reservation>> FindByFilterAsync(ReservationFilter filter);
    }
}
