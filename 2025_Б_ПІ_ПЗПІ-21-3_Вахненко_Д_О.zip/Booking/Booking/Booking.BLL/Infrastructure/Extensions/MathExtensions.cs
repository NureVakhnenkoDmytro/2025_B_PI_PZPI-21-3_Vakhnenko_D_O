﻿namespace Booking.BLL.Infrastructure.Extensions
{
    public static class MathExtensions
    {
        public static decimal PercentageRatioOfNumber(this decimal oldValue, decimal newValue)
        {
            if (oldValue == 0 || newValue == 0)
            {
                return 0;
            }

            return (100 - (newValue / oldValue * 100)) * -1;
        }

        public static decimal Average(params decimal[] values)
        {
            int count = values.Count(v => v > 0);

            if (count == 0)
            {
                return 0;
            }

            return values.Sum() / count;
        }
    }
}
