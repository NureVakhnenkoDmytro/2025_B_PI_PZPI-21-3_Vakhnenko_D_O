﻿using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Reflection;

namespace Booking.BLL.Infrastructure.Extensions
{
    public static class ObjectExtensions
    {
        public static string DisplayFor<T, TProperty>(this T obj, Expression<Func<T, TProperty>> expression)
        {
            if (expression.Body is not MemberExpression memberExpression)
                throw new ArgumentException($"The provided expression contains a {expression.GetType().Name} which is not supported. Only simple member accessors (fields, properties) of an object are supported.");
            
            return obj?.GetType()?.GetMember(memberExpression.Member.Name)?.FirstOrDefault()?.GetCustomAttribute<DisplayAttribute>()?.GetName() ?? string.Empty;
        }

        public static string DisplayFor<T>(this T obj)
        {
            return obj?.GetType()?.GetCustomAttribute<DisplayAttribute>()?.GetName() ?? string.Empty;
        }

        public static string DisplayName(this Enum enumValue)
        {
            return enumValue.GetType().GetMember(enumValue.ToString()).First().GetCustomAttribute<DisplayAttribute>()?.GetName() ?? string.Empty;
        }
    }
}
