﻿namespace Booking.BLL.Infrastructure.Extensions
{
    public static class FormatExtensions
    {
        public static string ToPriceFormat(this decimal value) => value.ToString("N2");

        public static string ToDateTimeFormat(this DateTime value) => value.ToString("g");
        public static string ToDateFormat(this DateTime value) => value.Date.ToString("dd.MM.yyyy");

        public static string ToPercentFormat(this decimal value) => ((double)Math.Truncate(value * 100) / 100).ToString("N2");
    }
}
