﻿using AutoMapper;
using Booking.BLL.Managers;
using Booking.BLL.Services.Entities;
using Booking.BLL.Services.Entities.Implementations;
using Booking.BLL.Services.Hosted;
using Booking.DAL.Infrastructure;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Booking.BLL.Infrastructure
{
    public static class DependencyInjections
    {
        public static IdentityBuilder ConfigureBLL(this IServiceCollection services, string connectionString)
        {
            return services.AddServices()
                .AddAutoMapper()
                .ConfigureDAL(connectionString)
                .AddManages();
        }

        public static void AddHostedServices(this IServiceCollection services)
        {
            services.AddHostedService<MidnightService>();
        }

        private static IServiceCollection AddServices(this IServiceCollection services)
        {
            return services
                .AddTransient<IAccommodationService, AccommodationService>()
                .AddTransient<IAnalyticsService, AnalyticsService>()
                .AddTransient<IReservationService, ReservationService>()
                .AddTransient<ICatalogueService, CatalogueService>()
                .AddTransient<IUserService, UserService>();
        }

        private static IdentityBuilder AddManages(this IdentityBuilder identityBuilder)
        {
            return identityBuilder
                .AddUserManager<UserManager>()
                .AddRoleManager<RoleManager>()
                .AddSignInManager<SignInManager>();
        }

        private static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            return services.AddSingleton(provider => new MapperConfiguration(mapperConfig =>
            {
                //mapperConfig.AddProfile(new ApiMappingProfile());
            }).CreateMapper());
        }
    }
}
