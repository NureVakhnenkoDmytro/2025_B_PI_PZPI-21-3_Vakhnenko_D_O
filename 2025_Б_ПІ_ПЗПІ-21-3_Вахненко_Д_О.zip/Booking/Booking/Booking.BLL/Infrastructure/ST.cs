﻿using Booking.BLL.Models.Catalogs;
using Booking.DAL.Entities;
using Booking.DAL.UnitOfWork;

namespace Booking.BLL.Infrastructure
{
    public static class ST
    {
        private static List<Catalog> _catalogs = new();

        #region Catalogs
        public static CatalogsList<Catalog> Catalogs => new(_catalogs);
        public static CatalogsList<Country> Countries => new(_catalogs);
        public static CatalogsList<Region> Regions => new(_catalogs);
        public static CatalogsList<DistanceFromCenter> DistanceFromCenters => new(_catalogs);
        public static CatalogsList<Amenities> Amenitiess => new(_catalogs);
        public static CatalogsList<RoomAmenities> RoomAmenities => new(_catalogs);
        public static CatalogsList<AmenitiesForPersonsWithDisabilities> AmenitiesForPersonsWithDisabilities => new(_catalogs);
        public static CatalogsList<CancellationPolicy> CancellationPolicies => new(_catalogs);
        public static CatalogsList<Food> Foods => new(_catalogs);
        public static CatalogsList<TypeAccommodation> TypeAccommodations => new(_catalogs);
        public static CatalogsList<Attractions> Attractions => new(_catalogs);
        public static CatalogsList<BedType> BedTypes => new(_catalogs);
        public static CatalogsList<Network> Networks => new(_catalogs);
        public static CatalogsList<Group> Groups => new(_catalogs);
        #endregion

        public static async Task ReloadCatalogsAsync(IUnitOfWork unitOfWork)
        {
            _catalogs = await unitOfWork.Catalogs.GetAllAsync();
        }
    }
}
